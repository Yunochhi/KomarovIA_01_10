﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KomarovIA_01_10
{
    public class Employer
    {
        string fullName;
        double category, workedDays, sickDays;

        public Employer(string fullName, double category, double workedDays, double sickDays)
        {
            this.fullName = fullName;
            this.category = category;
            this.workedDays = workedDays;
            this.sickDays = sickDays;
        }

        public double FindQ()
        {
            double q;

            q = (workedDays - sickDays) / 24 * category;
            
            return q;
        }
    }
}
