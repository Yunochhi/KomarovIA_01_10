﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KomarovIA_01_10
{
    class Program
    {
        static void Main(string[] args)
        {    
            //объявление переменных
            string fullName;
            int category, workedDays, sickDays, p;

            //Ввод данных и проверки на корректность данных
            Console.WriteLine("Введите ФИО: "); 
            fullName = Console.ReadLine();
            if (fullName == "") //Проверка на пустую строку
            {
                Console.WriteLine("Введите корректное значение!: ");
                return;
            }
         
            Console.WriteLine("Введите категорию: ");
            if (!int.TryParse(Console.ReadLine(), out category))  //Проверка на ввод числа
            {
                Console.WriteLine("Введите корректное значение!: ");
                return;
            }

            if (category < 0 || category > 2) //Проверка на корректность категории
            {
                Console.WriteLine("Введите корректное значение!: ");
                return;
            }

            Console.WriteLine("Введите кол-во отработанных дней: ");
            if (!int.TryParse(Console.ReadLine(), out workedDays)) //Проверка на ввод числа
            {
                Console.WriteLine("Введите корректное значение!: ");
                return;
            }

            Console.WriteLine("Введите кол-во дней больничного: ");
            if (!int.TryParse(Console.ReadLine(), out sickDays)) //Проверка на ввод числа
            { 
                Console.WriteLine("Введите корректное значение!: ");
                return;
            }

            Console.WriteLine("Введите P: ");
            if (!int.TryParse(Console.ReadLine(), out p)) //Проверка на ввод числа
            {
                Console.WriteLine("Введите корректное значение!: ");
                return;
            }

            if(p <= 0) //Проверка на корректность наград
            {
                Console.WriteLine("Введите корректное значение!: ");
                return;
            }

            //Конструктор класса потомка
            EmployerDescendant emploerDesc = new EmployerDescendant(fullName, category, workedDays, sickDays, p);
            
            Console.WriteLine($"QP = {emploerDesc.FindQP()}");
            Console.WriteLine($"Q = {emploerDesc.FindQ()}");
        }
    }
}
