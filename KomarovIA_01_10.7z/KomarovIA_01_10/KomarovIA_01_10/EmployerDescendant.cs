﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KomarovIA_01_10
{
    public class EmployerDescendant : Employer
    {
        string fullName;
        double category, workedDays, sickDays, p;
        public EmployerDescendant(string fullName, double category, double workedDays, double sickDays, int p ) : base(fullName, category, workedDays, sickDays)
        {
            this.fullName = fullName;
            this.category = category;
            this.workedDays = workedDays;
            this.sickDays = sickDays;
            this.p = p;
        }

     
        public double FindQP()
        {
            double Qp = 0.0;

            if (category == 2)
            {
                Qp = FindQ() + p / 2;           
            }
            else if (category < 2)
            {
                Qp = FindQ() + p / 3;           
            }
            return Qp;
        }
    }
}
