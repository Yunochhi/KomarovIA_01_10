﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

using KomarovIA_01_10;

namespace UnitTestProject_KomarovIA
{
    [TestClass]
    public class UnitTest1
    {
        EmployerDescendant employerDesc = new EmployerDescendant("Комаров Иван Алексеевич", 2, 21, 3, 10); // category = 2
        EmployerDescendant employerDesc2 = new EmployerDescendant("Комаров Иван Алексеевич", 1, 21, 3, 10); // category < 2

        [TestMethod]
        public void TestFindQ() // Если category = 2
        {
            double expect = employerDesc.FindQ();

            double actual = 1.5;

            Assert.AreEqual(expect, actual);

        }

        [TestMethod]
        public void TestFindQ2() // Если category < 2
        {
            double expect = employerDesc2.FindQ();

            double actual = 0.75;

            Assert.AreEqual(expect, actual);

        }

        [TestMethod]
        public void TestFindQp() // Если category = 2
        {
            double expect = Math.Round(employerDesc.FindQP(), 2);

            double actual = 6.5;

            Assert.AreEqual(expect, actual);

        }

        [TestMethod]
        public void TestFindQp2() // Если category < 2
        {
            double expect = Math.Round(employerDesc2.FindQP(), 2);

            double actual = 4.08;

            Assert.AreEqual(expect, actual);
        }
    }
}
